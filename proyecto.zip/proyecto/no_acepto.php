<?php 
 ini_set( 'display_errors', 1 );
    error_reporting( E_ALL );
$from = "parkingdomsystem@gmail.com";
$to = "jhamilton.pacanchique@telefonica.com,hgpacanchiquec@correo.udistrital.edu.co";
$subject = " Marcela No acepto";
$message = "Marcela No acepto";
$headers = "From:".$from;

mail($to, $subject, $message, $headers);


?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>inicio</title>
  <link rel="shortcut icon" href="img/corazon.ico">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <link rel="stylesheet" media="screen" href="css/style.css">
</head>
<body>


    
 <div class="info" id="contenido">
	<h1 style="font-size:20px; color: antiquewhite">La información ha sido enviada con éxito.
    
     </h1>
     <img style="position:relative; left: 20px" src="img/llorando.png" height="100px" width="100px">

 <a  style="position:relative; top:45px; left:-60px"class=" btn boton" href="index.php" > Fin </a>
    
     
</div>

<!-- scripts -->
<script src="particles.js"></script>
<script src="js/app.js"></script>
<script src="js/jquery.js"></script>


</body>
</html>