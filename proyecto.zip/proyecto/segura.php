<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>inicio</title>
  <link rel="shortcut icon" href="img/corazon.ico">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <link rel="stylesheet" media="screen" href="css/style.css">
</head>
<body>


	<h1 style="color:antiquewhite; position: relative; left:-20px">¿Segura?</h1>
     
  <a style="position:relative; left: 170px;top:40px" class=" btn boton" href="#" onclick="no_acepto()">NO</a>  
 <a style="position:relative; left: 20px;top:40px" class=" btn boton" href="#" onclick="cargaContenido7()">SI</a>


<!-- scripts -->
<script src="particles.js"></script>
<script src="js/app.js"></script>
<script src="js/jquery.js"></script>    


</body>
</html>