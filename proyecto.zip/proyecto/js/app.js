
particlesJS('particles-js',
  
  {
    "particles": {
      "number": {
        "value": 250,
        "density": {
          "enable": true,
          "value_area": 800
        }
      },
      "color": {
        "value": "#ffffff"
      },
      "shape": {
        "type": "circle",
        "stroke": {
          "width": 0,
          "color": "#000000"
        },
        "polygon": {
          "nb_sides": 5
        },
        "image": {
          "src": "img/github.svg",
          "width": 100,
          "height": 100
        }
      },
      "opacity": {
        "value": 0.5,
        "random": false,
        "anim": {
          "enable": false,
          "speed": 1,
          "opacity_min": 0.1,
          "sync": false
        }
      },
      "size": {
        "value": 5,
        "random": true,
        "anim": {
          "enable": false,
          "speed": 40,
          "size_min": 0.1,
          "sync": false
        }
      },
      "line_linked": {
        "enable": true,
        "distance": 150,
        "color": "#ffffff",
        "opacity": 0.4,
        "width": 1
      },
      "move": {
        "enable": true,
        "speed": 6,
        "direction": "none",
        "random": false,
        "straight": false,
        "out_mode": "out",
        "attract": {
          "enable": false,
          "rotateX": 600,
          "rotateY": 1200
        }
      }
    },
    "interactivity": {
      "detect_on": "canvas",
      "events": {
        "onhover": {
          "enable": true,
          "mode": "repulse"
        },
        "onclick": {
          "enable": true,
          "mode": "push"
        },
        "resize": true
      },
      "modes": {
        "grab": {
          "distance": 400,
          "line_linked": {
            "opacity": 1
          }
        },
        "bubble": {
          "distance": 400,
          "size": 40,
          "duration": 2,
          "opacity": 8,
          "speed": 3
        },
        "repulse": {
          "distance": 200
        },
        "push": {
          "particles_nb": 4
        },
        "remove": {
          "particles_nb": 2
        }
      }
    },
    "retina_detect": true,
  }

);

function cargaContenido(){
    var x = $('#contenido');
    x.load('inicio2.php');
      return false;
  }

function cargaContenido2(){
    var x = $('#contenido');
    x.load('fin.php');
      return false;
  }


function cargaContenido3(){
    var x = $('#contenido');
    x.load('sal.php');
      return false;
  }

function cargaContenido4(){
    var x = $('#contenido');
    x.load('olvidaba.php');
      return false;
  }

function cargaContenido5(){
    var x = $('#contenido');
    x.load('final.php');
    x.css("background", " rgba(0, 0, 0, 0)");
      return false;
  }

function cargaContenido6(){
    var x = $('#contenido');
    x.load('segura.php');
     x.css("background", " rgba(0, 0, 0, 0.3)");
    x.css( "height","300px");
      return false;
  }


function cargaContenido7(){
    var x = $('#contenido');
    x.load('sin_vuelta.php');
     x.css( "width","400px");
      return false;
  }


function cargaContenido8(){
    var x = $('#contenido');
    x.load('gracias.php');
    x.css("background", " rgba(0, 0, 0, 0)");
      return false;
  }



function exitoso(){
    var x = $('#contenido');
    x.load('exitoso.php');
      return false;
  }


function no_acepto(){
    var x = $('#contenido');
    x.load('no_acepto.php');
      return false;
  }
