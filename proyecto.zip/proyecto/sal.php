<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>inicio</title>
  <link rel="shortcut icon" href="img/corazon.ico">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <link rel="stylesheet" media="screen" href="css/style.css">
</head>
<body>

	<h1>¡Eyy, ya se acabó!...</h1>

 <a style="position:relative; top:50px" class=" btn boton" href="#" onclick="cargaContenido4()"> Continuar </a>


<!-- scripts -->
<script src="particles.js"></script>
<script src="js/app.js"></script>
<script src="js/jquery.js"></script>


</body>
</html>