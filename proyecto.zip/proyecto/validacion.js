

function validar(){
 
    
    var nombre = document.forms["formulario"].elements[0].value;
    var fecha = document.forms["formulario"].elements[1].value;
    var regexp_nombre = /^[A-Z\ñ]+$/i;
    
if (nombre == null || nombre.length == 0) {
    alert("Por favor ingresa el nombre ");
    return false; 
  }else {
      if (regexp_nombre.test(nombre)){  
          if(nombre == "Marcela" || nombre == "marcela" || nombre == "MARCELA"){
          
             if (fecha == null || fecha.length == 0) {
                    alert("Por favor ingresa la fecha ");
                    return false; 
              }else {
                        if(fecha == "2019-03-28"){

                          $("#fecha").removeClass("has-error");

                         }else{
                              alert("La fecha no es correcta, intenta de nuevo.");
                              return false;    
                         }
             }

          }else{
             alert("El nombre no es correcto, intenta de nuevo.");
               return false;    
         }
      }else{
          alert("Por favor ingresa caractéres válidos en el campo nombre. ");
          return false; 
      }
    
  }
  
    
  
    
    
    
}