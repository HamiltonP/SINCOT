<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>inicio</title>
  <link rel="shortcut icon" href="img/corazon.ico">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <link rel="stylesheet" media="screen" href="css/style.css">
</head>
<body>

    
     <p style="position:relative; top: 100px">  A pesar de tantas dudas, inconsistencias y miedos; con tu magia y tranquilidad me has ayudado a superarlos y a creer de nuevo que existen personas maravillosas... </p>
 <a style="position: relative; top:240px" class=" btn boton" href="#" onclick="cargaContenido2()"> Continuar </a>
    


<!-- scripts -->
<script src="particles.js"></script>
<script src="js/app.js"></script>
<script src="js/jquery.js"></script>


</body>
</html>