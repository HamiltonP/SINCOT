<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>inicio</title>
  <link rel="shortcut icon" href="img/corazon.ico">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <link rel="stylesheet" media="screen" href="css/style.css">
</head>
<body>


    
 <div style="position:relative; top:200px; "class="text" id="contenido">
	<h1 style="font-size:55px">¡Gracias!</h1>
     
     <p style=" position:relative; left:-30px; height: 200px; width: 350px"> Prometo intentar hacerte sonreír, apoyarte, acompañarte y cuidarte cada día en el tiempo que me lo permitas, daré lo mejor por que te sientas cómoda, feliz y que podamos estar mucho mucho tiempo juntos. </p>
 <a  class=" btn boton" href="#" onclick="exitoso()"> Continuar </a>
    
     
</div>

<!-- scripts -->
<script src="particles.js"></script>
<script src="js/app.js"></script>
<script src="js/jquery.js"></script>


</body>
</html>