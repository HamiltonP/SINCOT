<!DOCTYPE html>
<html lang="en">
<head>
 <link rel="shortcut icon" href="img/corazon.ico">
  <meta charset="utf-8">
  <title>Inicio</title>
    
    
  <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <link rel="stylesheet" media="screen" href="css/style.css">
  <script src="validacion.js"></script>
</head>
<body>

<!-- particles.js container -->
<div id="particles-js"></div>
    
    
 <div class="text">
    <h1>¡Hola!</h1>
    <hr>
    <form  id="formulario" action="inicio.php" method="post" onsubmit=" return validar();" >
               <label> Ingresa tu primer nombre: </label>
                <br>
                <br>
               <input type="text" id="nombre" name="nombre" data-validate="Ingrese el nombre " placeholder="Nombre">
                <br>
                <br>
                <label> Ingresa "la fecha": </label>
               <br>
                <br>
               <input type="date" name="fecha" >
           
               <input style="position:relative; top:60px; left:60px" class="boton" type="submit" value="Aceptar" >

     </form>
     
</div>

<!-- scripts -->
<script src="particles.js"></script>
<script src="js/app.js"></script>


</body>
</html>