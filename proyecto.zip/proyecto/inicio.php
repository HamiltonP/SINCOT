<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>inicio</title>
  <link rel="shortcut icon" href="img/corazon.ico">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <link rel="stylesheet" media="screen" href="css/style.css">
</head>
<body>

<!-- particles.js container -->
<div id="particles-js"></div>
    
    
 <div class="text" id="contenido">
	<h1 style="font-size:55px">¡Hola Marcela!</h1>
     
     <p><br> Si hay algo destinado a suceder, sucederá en el momento adecuado, con la persona correcta y por la mejor razón. 
         Todo tiene un por qué... </p>
     
 <a  class=" btn boton" href="#" onclick="cargaContenido()"> Continuar </a>
    
     
</div>

<!-- scripts -->
<script src="particles.js"></script>
<script src="js/app.js"></script>
<script src="js/jquery.js"></script>


</body>
</html>