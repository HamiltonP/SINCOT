<?php
class ruta {
	const ruta="/login-mvc";
}
?>