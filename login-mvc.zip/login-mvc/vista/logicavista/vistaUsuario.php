<?php

class vistaUsuario {    
    
    function vistaAcercaDe(){
        $cad='';
        return $cad;
    }
    
}
?>